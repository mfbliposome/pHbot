#ifndef PHBOT_CALIBRATION_H
#define PHBOT_CALIBRATION_H

#include <Arduino.h>

float whatValuepH (int bufferNumber);
int readVolts (int probeNumber);
float calculateSlope (float y2, float y1, int x2, int x1);
float calculateIntercept (float y2, float y1, int x2, int x1, float m);

#endif